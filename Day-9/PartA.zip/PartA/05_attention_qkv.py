# Simple conceptual example of Query, Key and Value.

sentence = ["The", "student", "opened", "the", "book"]

query = "student"
keys = sentence
values = sentence

print("Query:", query)
print("Keys:", keys)
print("Values:", values)

print("\nConcept:")
print("Query = what information am I looking for?")
print("Key   = what information does each token represent?")
print("Value = information available if that key is relevant.")

print("\nAttention compares a query with keys and uses the scores to combine values.")
