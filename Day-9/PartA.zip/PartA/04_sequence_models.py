# A sequence is data where order matters.

sentence = ["I", "love", "Python"]

print("Sequence:")
for position, word in enumerate(sentence):
    print(position, "->", word)

print("\nOrder matters:")
print("I love Python")
print("Python love I")

print("\nSequence models try to use information from earlier parts of a sequence.")
print("Transformers handle long-range relationships using attention.")
