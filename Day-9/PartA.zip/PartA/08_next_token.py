# LLMs are trained to predict the next token.

examples = [
    "The sun rises in the",
    "Python is a programming",
    "Artificial Intelligence is"
]

for text in examples:
    print("Prompt:", text)
    print("Task: predict the next token")
    print()

print("This simple prediction task is a core idea behind causal language models.")
