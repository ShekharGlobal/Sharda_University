# Transformers need position information because attention itself does not mean
# "first word", "second word", etc.

words = ["AI", "helps", "students"]

print("Token positions:")
for position, word in enumerate(words):
    print(f"{position}: {word}")

print("\nWithout position information:")
print("AI helps students")
print("students helps AI")
print("would contain the same words but different order.")

print("\nPositional information helps the model understand token order.")
