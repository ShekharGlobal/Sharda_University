from transformers import AutoTokenizer

model_name = "Qwen/Qwen2.5-0.5B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(model_name)

text = "AI " * 100

ids = tokenizer.encode(text)

print("Number of tokens in sample:", len(ids))
print("Token count depends on the tokenizer.")

print("\nContext window = the amount of token information a model can consider")
print("for a particular request/conversation.")
print("If a conversation becomes too long, older information may need to be removed or summarized.")
