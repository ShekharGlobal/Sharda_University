# Generation controls change which next tokens can be selected.

settings = [
    {"temperature": 0.1, "top_k": 10, "top_p": 0.9},
    {"temperature": 0.7, "top_k": 50, "top_p": 0.9},
    {"temperature": 1.2, "top_k": 100, "top_p": 0.95},
]

for s in settings:
    print(s)

print("\nTemperature: controls how strongly probabilities are concentrated.")
print("Top-k: considers only the k most likely tokens.")
print("Top-p: considers the smallest group whose cumulative probability reaches p.")
print("Higher randomness can produce more varied answers, but may reduce consistency.")
