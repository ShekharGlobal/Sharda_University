# Day 9 – Part A: How Large Language Models Work

Beginner-friendly concept demonstrations for VS Code + Python.

## Setup
```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install transformers torch
```

For Qwen tokenizer/model demos, the first run downloads the model files from Hugging Face.

## Files
01_ngram.py
02_tokenization.py
03_embeddings.py
04_sequence_models.py
05_attention_qkv.py
06_multi_head_attention.py
07_positional_encoding.py
08_next_token.py
09_autoregressive.py
10_pretraining_sft_rlhf.py
11_temperature_topk_topp.py
12_context_window.py
13_hallucination.py
14_bias_safety.py
15_model_families.py

Each program is intentionally small and contains beginner comments.

## Suggested teaching order
1. N-grams
2. Tokens
3. Embeddings
4. Sequence models
5. Attention and Q/K/V
6. Multi-head attention
7. Positional encoding
8. Next-token prediction
9. Autoregressive generation
10. Pretraining, SFT and RLHF
11. Generation controls
12. Context window
13. Hallucination
14. Bias, safety and responsible AI
15. Model families

## Important
Some topics such as pretraining, RLHF and multi-head attention are demonstrated conceptually rather than by training a large LLM from scratch. This keeps the exercises suitable for student laptops.
