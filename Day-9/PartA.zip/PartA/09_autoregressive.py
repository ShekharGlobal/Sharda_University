# Autoregressive generation: generate one piece, then use it to generate the next.

generated = ["Artificial"]

next_tokens = ["Intelligence", "helps", "people"]

for token in next_tokens:
    generated.append(token)
    print("Current text:", " ".join(generated))

print("\nThe generated text grows step by step.")
