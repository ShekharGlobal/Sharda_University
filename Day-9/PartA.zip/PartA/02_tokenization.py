from transformers import AutoTokenizer

model_name = "Qwen/Qwen2.5-0.5B-Instruct"
tokenizer = AutoTokenizer.from_pretrained(model_name)

text = "Artificial Intelligence is amazing!"

tokens = tokenizer.tokenize(text)
ids = tokenizer.encode(text)

print("Text:", text)
print("\nTokens:")
print(tokens)

print("\nToken IDs:")
print(ids)

print("\nNumber of tokens:", len(ids))
print("Number of words:", len(text.split()))

print("\nIdea: LLMs process tokens, not whole words directly.")
