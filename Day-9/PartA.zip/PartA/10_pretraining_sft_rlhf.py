# Three important stages/ideas.

stages = {
    "Pretraining": "Learn general language patterns from very large datasets.",
    "SFT": "Supervised fine-tuning teaches desired instruction-following behavior.",
    "RLHF / preference tuning": "Human or preference signals help improve useful behavior."
}

for stage, explanation in stages.items():
    print(stage)
    print("  ", explanation)
    print()

print("These stages are conceptual; this program does not train an LLM.")
