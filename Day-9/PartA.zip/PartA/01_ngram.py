# N-gram example
# A bigram contains 2 consecutive words.

text = "I love machine learning and I love Python"

# Convert sentence into a list of words
words = text.split()

print("Words:")
print(words)

print("\nBigrams:")

# Take two words at a time
for i in range(len(words) - 1):
    bigram = (words[i], words[i + 1])
    print(bigram)

print("\nIdea:")
print("A bigram uses the current word and the next word.")

print("\nExample:")
print("If we see 'I love', the model can learn that 'love' often follows 'I'.")

print("\nModern LLMs:")
print("Modern LLMs do not use simple n-grams.")
print("They use transformer architectures and attention to understand relationships between tokens.")