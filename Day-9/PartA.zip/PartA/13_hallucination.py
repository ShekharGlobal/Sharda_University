from ollama import chat

prompt = """
Answer this question. If you are not sure, clearly say that you are not sure.
Do not invent facts.

Question: Who invented the fictional technology called Quantum Pencil in 1897?
"""

try:
    response = chat(
        model="qwen2.5:0.5b",
        messages=[{"role": "user", "content": prompt}]
    )
    print(response.message.content)
except Exception as e:
    print("Ollama/Qwen is not running.")
    print("Start Ollama and run: ollama run qwen2.5:0.5b")

print("\nHallucination = a model producing information that sounds plausible but is incorrect or unsupported.")
