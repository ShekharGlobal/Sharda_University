from transformers import AutoTokenizer, AutoModel

model_name = "Qwen/Qwen2.5-0.5B-Instruct"

tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModel.from_pretrained(model_name)

text = "AI is useful."

inputs = tokenizer(text, return_tensors="pt")

outputs = model(**inputs)

# Last hidden state contains vector representations.
vectors = outputs.last_hidden_state

print("Input:", text)
print("Vector tensor shape:", vectors.shape)
print("\nEach token is represented internally using numbers.")
print("These numerical representations are called embeddings/hidden representations.")
