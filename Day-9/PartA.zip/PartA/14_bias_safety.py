# Responsible AI checklist

checks = [
    "Check important facts instead of blindly trusting model output.",
    "Protect personal and confidential information.",
    "Test prompts for unfair or harmful outputs.",
    "Use human review for high-impact decisions.",
    "Tell users when AI is being used when appropriate."
]

print("Responsible AI checklist:")
for i, item in enumerate(checks, 1):
    print(f"{i}. {item}")

print("\nAI safety is not only a model problem; it also depends on how the system is designed and used.")
