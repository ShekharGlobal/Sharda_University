# A model family can contain different sizes and variants.

models = [
    "Qwen2.5-0.5B-Instruct",
    "Qwen2.5-1.5B",
    "Qwen2.5-3B",
    "Qwen2.5-7B"
]

print("Example Qwen2.5 model variants:")
for model in models:
    print("-", model)

print("\nModel size is often described using parameter count.")
print("Larger models can require more memory and compute.")
print("For classroom practice, a small model such as Qwen2.5 0.5B is easier to run locally.")
