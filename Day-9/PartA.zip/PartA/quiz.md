# Part A Quiz

1. What is an n-gram?
2. What is a token?
3. Why do LLMs use tokens?
4. What is an embedding?
5. Why does word order matter?
6. What is attention?
7. What does Q mean in Q/K/V?
8. What does K mean?
9. What does V mean?
10. Why use multiple attention heads?
11. Why is positional information needed?
12. What is next-token prediction?
13. What does autoregressive mean?
14. What is pretraining?
15. What is SFT?
16. What is RLHF/preference tuning?
17. What does temperature control?
18. What is top-k?
19. What is top-p?
20. What is a context window?
21. What is hallucination?
22. Give two responsible-AI practices.
23. Why might a student choose a small local model?
24. What is the difference between a model family and one specific model?
