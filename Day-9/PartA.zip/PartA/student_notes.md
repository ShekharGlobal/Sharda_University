# Part A Quick Notes

## 1. N-grams
Use a fixed number of previous words to estimate what comes next.

## 2. Tokens
The text is split into pieces called tokens. A token may be a whole word, part of a word, punctuation, etc.

## 3. Embeddings
Tokens are converted into numerical representations so neural networks can process relationships between them.

## 4. Sequence models
Language is sequential. Word/token order matters.

## 5. Attention
Attention lets a token focus on other relevant tokens.

### Q/K/V
- Query: what the current token is looking for
- Key: what each token offers for matching
- Value: information that can be collected

## 6. Multi-head attention
Multiple attention heads can learn different relationships in parallel.

## 7. Positional encoding
Provides information about token positions/order.

## 8. Next-token prediction
A causal language model predicts what token should come next.

## 9. Autoregressive generation
The model repeatedly predicts the next token and adds it to the output.

## 10. Training
- Pretraining: broad language learning
- SFT: instruction-following examples
- RLHF/preference tuning: improve helpfulness and behavior using preferences

## 11. Generation controls
- Temperature: output variability
- Top-k: limit candidates to k tokens
- Top-p: limit candidates by cumulative probability
- max_new_tokens: limit generated length

## 12. Context window
The token capacity available to a request/conversation.

## 13. Hallucination
Plausible-sounding but incorrect or unsupported output.

## 14. Bias and safety
Models can reproduce problematic patterns from data or instructions. Responsible systems use testing, safeguards, privacy protection and human review.

## 15. Model families
A family may provide different model sizes and variants for different hardware and tasks.
