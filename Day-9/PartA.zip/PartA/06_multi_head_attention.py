# Multi-head attention = several attention patterns working in parallel.

sentence = "The student read a book about AI"

heads = {
    "Head 1": "may focus on nearby word relationships",
    "Head 2": "may focus on subject/action relationships",
    "Head 3": "may focus on longer-range relationships"
}

print("Sentence:", sentence)

for head, focus in heads.items():
    print(head, ":", focus)

print("\nAfter processing, the heads are combined.")
print("This gives the transformer multiple ways to examine relationships.")
